package me.casper.companion;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public final class CasperCompanion implements ClientModInitializer {
    public static final String VERSION = "1.1.3";
    private static int handshakeTicks = -1;
    private static boolean handshakeSent = false;
    private static int onboardingTicks = -1;

    @Override
    public void onInitializeClient() {
        System.out.println("[Casper Companion] Loaded v" + VERSION + " for Minecraft 1.21.11");

        PayloadTypeRegistry.playC2S().register(HelloPayload.ID, HelloPayload.CODEC);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("info").executes(context -> {
                MinecraftClient.getInstance().setScreen(new InfoScreen(0));
                return 1;
            }))
        );

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            // Paper may not advertise plugin channels until just after the play connection is ready.
            // Start a short retry window instead of sending once too early.
            handshakeTicks = 0;
            handshakeSent = false;
            onboardingTicks = 20;
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            handshakeTicks = -1;
            handshakeSent = false;
            onboardingTicks = -1;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getNetworkHandler() == null) {
                return;
            }

            if (!handshakeSent && handshakeTicks >= 0) {
                handshakeTicks++;
                try {
                    if (ClientPlayNetworking.canSend(HelloPayload.ID)) {
                        ClientPlayNetworking.send(new HelloPayload(("HELLO|" + VERSION).getBytes(StandardCharsets.UTF_8)));
                        handshakeSent = true;
                        System.out.println("[Casper Companion] Verification hello sent after channel became available");
                    } else if (handshakeTicks % 20 == 0) {
                        System.out.println("[Casper Companion] Waiting for server channel casper:suite (" + handshakeTicks + " ticks)");
                    }
                } catch (Throwable t) {
                    if (handshakeTicks % 20 == 0) {
                        System.err.println("[Casper Companion] Verification send attempt failed: " + t);
                    }
                }

                // Stop retrying after 15 seconds. The server's kick timer is normally 20 seconds.
                if (handshakeTicks >= 300 && !handshakeSent) {
                    System.err.println("[Casper Companion] Server never exposed casper:suite as a sendable channel");
                    handshakeTicks = -1;
                }
            }

            if (onboardingTicks > 0) {
                onboardingTicks--;
            } else if (onboardingTicks == 0) {
                onboardingTicks = -1;
                if (client.currentScreen == null) {
                    client.setScreen(new InfoScreen(0));
                }
            }
        });
    }


    public record HelloPayload(byte[] data) implements CustomPayload {
        public static final Id<HelloPayload> ID = new Id<>(Identifier.of("casper", "suite"));
        public static final PacketCodec<RegistryByteBuf, HelloPayload> CODEC = PacketCodec.of(
            (payload, buf) -> buf.writeBytes(payload.data()),
            buf -> {
                byte[] bytes = new byte[buf.readableBytes()];
                buf.readBytes(bytes);
                return new HelloPayload(bytes);
            }
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static final class InfoScreen extends Screen {
        private static final int WHITE = 0xFFFFFF;
        private static final int MUTED = 0xB8B8B8;
        private static final int ACCENT = 0xFFE06B;

        private static final List<Page> PAGES = List.of(
            new Page("Welcome / Quick Start", List.of(
                "Welcome to the custom SMP.",
                "This guide explains every custom system and how to use it.",
                "Use /info at any time to reopen this menu.",
                "Your class is assigned randomly the first time you join.",
                "Server-side settings are authoritative; the companion only provides UI/visual features.",
                "Use the Next/Previous buttons to read every section."
            )),
            new Page("Combat Rules", List.of(
                "Combat tagging lasts 15 seconds after PvP combat.",
                "Logging out while combat-tagged causes your character to die.",
                "Elytra use is blocked while combat-tagged.",
                "If combat begins while you are gliding, gliding is stopped.",
                "Ender Pearl projectiles despawn after 30 seconds.",
                "Hunter-class combat involvement can last 90 seconds."
            )),
            new Page("World / Admin Systems", List.of(
                "Admins can enable or disable the Overworld, Nether, and End.",
                "If a dimension is disabled, normal players cannot enter it.",
                "Admins can disable or modify existing crafting recipes.",
                "Recipe changes are intended to persist through restarts.",
                "Underground anti-Xray protection is intended for Y -64 through Y 0.",
                "The anti-dupe / unique-stack-ID system was removed."
            )),
            new Page("Mob Spawn Radius", List.of(
                "Every player has a personal mob-spawn radius from 0 to 12 chunks.",
                "0 means natural mobs do not spawn around you.",
                "1-12 sets how far around you natural spawning is allowed.",
                "The setting applies to all naturally spawning mobs.",
                "The server stores and enforces your selection."
            )),
            new Page("Classes: Miner / Contractor", List.of(
                "MINER: 10% chance to duplicate an ore block when mined.",
                "Fortune does not increase or modify the class's bonus duplicate.",
                "CONTRACTOR: can post contracts and accept contracts.",
                "Only Contractors may accept contracts.",
                "A Contractor may have at most 3 active contracts.",
                "Contracts do not expire; the poster chooses and deposits the reward in the UI."
            )),
            new Page("Classes: Child / Bloodthirsty", List.of(
                "CHILD: -4 max HP, 0.75x size/hitbox, 1.5x sprint speed.",
                "Child hunger drains 1.5x faster.",
                "BLOODTHIRSTY: has Weakness I until getting a player kill.",
                "A player kill gives Strength I for 10 minutes.",
                "Each additional player kill adds 10 minutes to the timer.",
                "Strength stays at I. Death resets the timer back to Weakness I.",
                "The timer continues while offline and is kept separate from normal potions."
            )),
            new Page("Classes: Builder / Hunter", List.of(
                "BUILDER: 10% chance to refund a placed block.",
                "Builder refund is disabled while combat-tagged.",
                "Storage-value blocks and Shulker Boxes are excluded from refunds.",
                "HUNTER: chase range is 50 blocks with about a 30-degree forward cone.",
                "Hunter gets Speed I while the chase condition is active.",
                "Line of sight is not required.",
                "The class Speed effect is designed not to break normal Speed potions."
            )),
            new Page("Classes: Camo / Ranged", List.of(
                "CAMO EXPERT: you do not see your own potion particles.",
                "RANGED EXPERT: ranged weapon use is 40% faster.",
                "Ranged Expert applies to bows, crossbows, and tridents.",
                "Some visual/timing parts require this companion mod."
            )),
            new Page("Classes: Melee / Village", List.of(
                "MELEE EXPERT: choose 2 positive effects and 2 negative effects.",
                "All potion-effect types are available for selection.",
                "Chosen positive effects last 15% longer.",
                "Chosen negative effects last 20% less time.",
                "MASTER OF THE VILLAGE: 20% villager trade discount.",
                "The discount applies after other discounts; final cost is at least 1 emerald."
            )),
            new Page("Changing Class", List.of(
                "A one-time class-change item lets you choose a different class.",
                "It is crafted shapelessly with:",
                "4 Diamond Blocks + 1 Nether Star + 2 Gold Blocks.",
                "Use the item to open class selection.",
                "The item is consumed when used and the class change is one-time."
            )),
            new Page("Companion / Verification", List.of(
                "The Java companion provides client UI and required client-side features.",
                "The security plugin can verify that the companion is present.",
                "Bedrock players use the server's Geyser/Floodgate-compatible interfaces instead.",
                "The server does not magically read every installed mod.",
                "Verification and server-side behaviour checks are used instead.",
                "If you forget anything, run /info again."
            ))
        );

        private final int pageIndex;

        public InfoScreen(int pageIndex) {
            super(Text.literal("Casper SMP Guide"));
            this.pageIndex = Math.max(0, Math.min(pageIndex, PAGES.size() - 1));
        }

        @Override
        protected void init() {
            int bottom = this.height - 30;
            int buttonWidth = 90;
            int gap = 6;
            int total = buttonWidth * 3 + gap * 2;
            int startX = (this.width - total) / 2;

            if (pageIndex > 0) {
                this.addDrawableChild(ButtonWidget.builder(Text.literal("Previous"), b ->
                    this.client.setScreen(new InfoScreen(pageIndex - 1))
                ).dimensions(startX, bottom, buttonWidth, 20).build());
            }

            this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b ->
                this.client.setScreen(null)
            ).dimensions(startX + buttonWidth + gap, bottom, buttonWidth, 20).build());

            if (pageIndex < PAGES.size() - 1) {
                this.addDrawableChild(ButtonWidget.builder(Text.literal("Next"), b ->
                    this.client.setScreen(new InfoScreen(pageIndex + 1))
                ).dimensions(startX + (buttonWidth + gap) * 2, bottom, buttonWidth, 20).build());
            }
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
            this.renderBackground(context, mouseX, mouseY, deltaTicks);

            Page page = PAGES.get(pageIndex);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Casper SMP Guide"), this.width / 2, 18, ACCENT);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(page.title()), this.width / 2, 38, WHITE);
            context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Page " + (pageIndex + 1) + " / " + PAGES.size()), this.width / 2, 53, MUTED);

            int y = 76;
            for (String line : page.lines()) {
                context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(line), this.width / 2, y, WHITE);
                y += 14;
            }

            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("/info reopens this guide anytime"),
                this.width / 2, this.height - 48, MUTED);
            super.render(context, mouseX, mouseY, deltaTicks);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }

    private record Page(String title, List<String> lines) {}
}

plugins {
    id("net.fabricmc.fabric-loom-remap") version property("loom_version") as String
    `maven-publish`
}
version=property("mod_version")!!
group=property("maven_group")!!
repositories { mavenCentral(); maven("https://maven.fabricmc.net/") }
dependencies {
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    mappings(loom.officialMojangMappings())
    modImplementation("net.fabricmc:fabric-loader:${property("loader_version")}")
    modImplementation("net.fabricmc.fabric-api:fabric-api:${property("fabric_api_version")}")
}
java { toolchain.languageVersion.set(JavaLanguageVersion.of(21)) }

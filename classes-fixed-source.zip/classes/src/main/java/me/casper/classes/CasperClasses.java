package me.casper.classes;

import org.bukkit.*;
import org.bukkit.attribute.*;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class CasperClasses extends JavaPlugin implements Listener {
    enum C { MINER, CONTRACTOR, CHILD, BLOODTHIRSTY, BUILDER, HUNTER, CAMO_EXPERT, RANGED_EXPERT, MELEE_EXPERT, MASTER_OF_THE_VILLAGE }
    private final Map<UUID,C> cls=new HashMap<>();
    private final Map<UUID,Long> bloodUntil=new HashMap<>();
    private final Map<UUID,UUID> hunterTarget=new HashMap<>();
    private final Map<UUID,Long> hunterUntil=new HashMap<>();
    private NamespacedKey changerKey;
    private final Set<Material> noRefund=EnumSet.of(Material.DIAMOND_BLOCK,Material.EMERALD_BLOCK,Material.NETHERITE_BLOCK,Material.IRON_BLOCK,Material.GOLD_BLOCK,Material.RAW_IRON_BLOCK,Material.RAW_GOLD_BLOCK,Material.RAW_COPPER_BLOCK,Material.SHULKER_BOX,Material.WHITE_SHULKER_BOX,Material.ORANGE_SHULKER_BOX,Material.MAGENTA_SHULKER_BOX,Material.LIGHT_BLUE_SHULKER_BOX,Material.YELLOW_SHULKER_BOX,Material.LIME_SHULKER_BOX,Material.PINK_SHULKER_BOX,Material.GRAY_SHULKER_BOX,Material.LIGHT_GRAY_SHULKER_BOX,Material.CYAN_SHULKER_BOX,Material.PURPLE_SHULKER_BOX,Material.BLUE_SHULKER_BOX,Material.BROWN_SHULKER_BOX,Material.GREEN_SHULKER_BOX,Material.RED_SHULKER_BOX,Material.BLACK_SHULKER_BOX);

    @Override public void onEnable(){saveDefaultConfig();changerKey=new NamespacedKey(this,"class_changer");load();registerRecipe();getServer().getPluginManager().registerEvents(this,this);Objects.requireNonNull(getCommand("class")).setExecutor(this::classCmd);Objects.requireNonNull(getCommand("contracts")).setExecutor(this::contractsCmd);Bukkit.getScheduler().runTaskTimer(this,this::tick,5L,5L);for(Player p:Bukkit.getOnlinePlayers())ensure(p);}
    @Override public void onDisable(){save();}

    private void registerRecipe(){ItemStack item=new ItemStack(Material.NETHER_STAR);ItemMeta m=item.getItemMeta();m.setDisplayName(ChatColor.LIGHT_PURPLE+"Class Changer");m.getPersistentDataContainer().set(changerKey,PersistentDataType.BYTE,(byte)1);item.setItemMeta(m);ShapelessRecipe r=new ShapelessRecipe(new NamespacedKey(this,"class_changer"),item);r.addIngredient(4,Material.DIAMOND_BLOCK);r.addIngredient(1,Material.NETHER_STAR);r.addIngredient(2,Material.GOLD_BLOCK);Bukkit.addRecipe(r);}
    private boolean classCmd(CommandSender s,Command c,String l,String[] a){if(!(s instanceof Player p))return true;ensure(p);p.sendMessage(ChatColor.AQUA+"Your class: "+pretty(cls.get(p.getUniqueId())));return true;}
    private boolean contractsCmd(CommandSender s,Command c,String l,String[] a){if(!(s instanceof Player p))return true;ensure(p);if(cls.get(p.getUniqueId())!=C.CONTRACTOR){p.sendMessage(ChatColor.RED+"Only Contractors can use the contract board.");return true;}p.sendMessage(ChatColor.YELLOW+"Contract board enabled. This build stores the Contractor class and enforces Contractor-only access; use the GUI module hook for custom contract creation/reward item selection.");return true;}

    private void ensure(Player p){if(cls.containsKey(p.getUniqueId())) return;C[] v=C.values();C c=v[ThreadLocalRandom.current().nextInt(v.length)];cls.put(p.getUniqueId(),c);getConfig().set("classes."+p.getUniqueId(),c.name());saveConfig();p.sendMessage(ChatColor.GOLD+"You were assigned the "+pretty(c)+" class!");describe(p,c);applyPersistent(p);}
    private void describe(Player p,C c){p.sendMessage(ChatColor.GRAY+switch(c){case MINER->"10% chance for an extra base ore drop; Fortune does not affect the bonus.";case CONTRACTOR->"Can post/accept contracts; max 3 active; no expiry.";case CHILD->"0.75x scale, -4 HP, 1.5x sprint speed, 1.5x hunger drain.";case BLOODTHIRSTY->"Weakness I until a player kill; then Strength I for 10 minutes, +10 minutes per kill.";case BUILDER->"10% block refund outside combat, excluding valuable storage/raw blocks and shulkers.";case HUNTER->"90s target tracking; Speed I when target is within 50 blocks and a 30-degree forward cone.";case CAMO_EXPERT->"Your own potion particles are hidden by the companion mod.";case RANGED_EXPERT->"40% faster bows, crossbows, and tridents with companion support.";case MELEE_EXPERT->"Choose 2 positive effects (+15% duration) and 2 negative effects (-20%).";case MASTER_OF_THE_VILLAGE->"20% villager trade discount after other discounts, minimum 1 emerald.";});}

    @EventHandler public void join(PlayerJoinEvent e){ensure(e.getPlayer());applyPersistent(e.getPlayer());}
    @EventHandler public void interact(PlayerInteractEvent e){ItemStack i=e.getItem();if(i==null||i.getType()!=Material.NETHER_STAR)return;Byte b=i.getItemMeta().getPersistentDataContainer().get(changerKey,PersistentDataType.BYTE);if(b==null)return;e.setCancelled(true);openClassPicker(e.getPlayer());}
    private void openClassPicker(Player p){Inventory inv=Bukkit.createInventory(null,18,"Choose your class");int n=0;for(C c:C.values()){ItemStack i=new ItemStack(icon(c));ItemMeta m=i.getItemMeta();m.setDisplayName(ChatColor.AQUA+pretty(c));m.getPersistentDataContainer().set(new NamespacedKey(this,"pick"),PersistentDataType.STRING,c.name());i.setItemMeta(m);inv.setItem(n++,i);}p.openInventory(inv);}
    @EventHandler public void picker(InventoryClickEvent e){if(!e.getView().getTitle().equals("Choose your class"))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getCurrentItem()==null)return;String s=e.getCurrentItem().getItemMeta().getPersistentDataContainer().get(new NamespacedKey(this,"pick"),PersistentDataType.STRING);if(s==null)return;C c=C.valueOf(s);consumeChanger(p);clearClassState(p);cls.put(p.getUniqueId(),c);applyPersistent(p);save();p.closeInventory();p.sendMessage(ChatColor.GREEN+"Class changed to "+pretty(c)+".");describe(p,c);}
    private void consumeChanger(Player p){for(ItemStack i:p.getInventory().getContents()){if(i==null||i.getType()!=Material.NETHER_STAR)continue;Byte b=i.getItemMeta().getPersistentDataContainer().get(changerKey,PersistentDataType.BYTE);if(b!=null){i.setAmount(i.getAmount()-1);return;}}}

    @EventHandler(ignoreCancelled=true) public void mine(BlockBreakEvent e){Player p=e.getPlayer();if(get(p)!=C.MINER||ThreadLocalRandom.current().nextDouble()>=0.10)return;ItemStack tool=p.getInventory().getItemInMainHand().clone();for(Enchantment en:new HashSet<>(tool.getEnchantments().keySet()))tool.removeEnchantment(en);Collection<ItemStack> drops=e.getBlock().getDrops(tool,p);if(isOre(e.getBlock().getType()))for(ItemStack d:drops)e.getBlock().getWorld().dropItemNaturally(e.getBlock().getLocation(),d.clone());}
    private boolean isOre(Material m){return m.name().endsWith("_ORE")||m==Material.ANCIENT_DEBRIS;}

    @EventHandler(ignoreCancelled=true) public void place(BlockPlaceEvent e){Player p=e.getPlayer();if(get(p)!=C.BUILDER||p.getScoreboardTags().contains("casper_combat_tagged")||noRefund.contains(e.getBlockPlaced().getType()))return;if(ThreadLocalRandom.current().nextDouble()<0.10)p.getInventory().addItem(new ItemStack(e.getBlockPlaced().getType()));}

    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void hit(EntityDamageByEntityEvent e){if(!(e.getEntity() instanceof Player v))return;Player a=damager(e.getDamager());if(a==null)return;long now=System.currentTimeMillis();if(get(a)==C.HUNTER){hunterTarget.put(a.getUniqueId(),v.getUniqueId());hunterUntil.put(a.getUniqueId(),now+90_000);}if(get(v)==C.HUNTER){hunterTarget.put(v.getUniqueId(),a.getUniqueId());hunterUntil.put(v.getUniqueId(),now+90_000);}}
    @EventHandler public void death(PlayerDeathEvent e){Player dead=e.getEntity();if(get(dead)==C.BLOODTHIRSTY){bloodUntil.remove(dead.getUniqueId());applyBlood(dead);}Player killer=dead.getKiller();if(killer!=null&&get(killer)==C.BLOODTHIRSTY){long now=System.currentTimeMillis();long base=Math.max(now,bloodUntil.getOrDefault(killer.getUniqueId(),now));bloodUntil.put(killer.getUniqueId(),base+600_000L);applyBlood(killer);save();}}

    @EventHandler public void exhaustion(EntityExhaustionEvent e){if(e.getEntity() instanceof Player p&&get(p)==C.CHILD)e.setExhaustion(e.getExhaustion()*1.5f);}

    private void tick(){long now=System.currentTimeMillis();for(Player p:Bukkit.getOnlinePlayers()){ensure(p);if(get(p)==C.BLOODTHIRSTY)applyBlood(p);if(get(p)==C.HUNTER)applyHunter(p,now);if(get(p)==C.CHILD)applyChild(p);}}
    private void applyPersistent(Player p){clearModifiers(p);C c=cls.get(p.getUniqueId());if(c==C.CHILD)applyChild(p);if(c==C.BLOODTHIRSTY)applyBlood(p);}
    private void clearClassState(Player p){clearModifiers(p);bloodUntil.remove(p.getUniqueId());hunterTarget.remove(p.getUniqueId());hunterUntil.remove(p.getUniqueId());}
    private void clearModifiers(Player p){removeMod(p,Attribute.MAX_HEALTH,"casper_child_hp");removeMod(p,Attribute.SCALE,"casper_child_scale");removeMod(p,Attribute.MOVEMENT_SPEED,"casper_child_speed");removeMod(p,Attribute.ATTACK_DAMAGE,"casper_blood");removeMod(p,Attribute.MOVEMENT_SPEED,"casper_hunter_speed");}
    private void applyChild(Player p){setMod(p,Attribute.MAX_HEALTH,"casper_child_hp",-4,AttributeModifier.Operation.ADD_NUMBER);setMod(p,Attribute.SCALE,"casper_child_scale",-0.25,AttributeModifier.Operation.ADD_SCALAR);double speed=p.isSprinting()?0.5:0.0;setMod(p,Attribute.MOVEMENT_SPEED,"casper_child_speed",speed,AttributeModifier.Operation.ADD_SCALAR);if(p.getHealth()>Objects.requireNonNull(p.getAttribute(Attribute.MAX_HEALTH)).getValue())p.setHealth(Objects.requireNonNull(p.getAttribute(Attribute.MAX_HEALTH)).getValue());}
    private void applyBlood(Player p){boolean strong=bloodUntil.getOrDefault(p.getUniqueId(),0L)>System.currentTimeMillis();setMod(p,Attribute.ATTACK_DAMAGE,"casper_blood",strong?3.0:-4.0,AttributeModifier.Operation.ADD_NUMBER);}
    private void applyHunter(Player p,long now){UUID tid=hunterTarget.get(p.getUniqueId());boolean ok=false;if(tid!=null&&hunterUntil.getOrDefault(p.getUniqueId(),0L)>now){Player t=Bukkit.getPlayer(tid);if(t!=null&&t.getWorld().equals(p.getWorld())&&p.getLocation().distanceSquared(t.getLocation())<=2500){var dir=p.getEyeLocation().getDirection().setY(0).normalize();var to=t.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0).normalize();double dot=dir.dot(to);ok=dot>=Math.cos(Math.toRadians(15));}}setMod(p,Attribute.MOVEMENT_SPEED,"casper_hunter_speed",ok?0.20:0.0,AttributeModifier.Operation.ADD_SCALAR);}
    private void setMod(Player p,Attribute a,String name,double amount,AttributeModifier.Operation op){AttributeInstance in=p.getAttribute(a);if(in==null)return;removeMod(p,a,name);if(amount==0)return;NamespacedKey k=new NamespacedKey(this,name);in.addModifier(new AttributeModifier(k,amount,op));}
    private void removeMod(Player p,Attribute a,String name){AttributeInstance in=p.getAttribute(a);if(in==null)return;NamespacedKey k=new NamespacedKey(this,name);for(AttributeModifier m:new ArrayList<>(in.getModifiers()))if(m.getKey().equals(k))in.removeModifier(m);}

    private Player damager(Entity e){if(e instanceof Player p)return p;if(e instanceof Projectile pr&&pr.getShooter() instanceof Player p)return p;return null;}
    private C get(Player p){if(!cls.containsKey(p.getUniqueId()))ensure(p);return cls.get(p.getUniqueId());}
    private Material icon(C c){return switch(c){case MINER->Material.IRON_PICKAXE;case CONTRACTOR->Material.WRITABLE_BOOK;case CHILD->Material.RABBIT_FOOT;case BLOODTHIRSTY->Material.REDSTONE;case BUILDER->Material.BRICKS;case HUNTER->Material.COMPASS;case CAMO_EXPERT->Material.POTION;case RANGED_EXPERT->Material.BOW;case MELEE_EXPERT->Material.IRON_SWORD;case MASTER_OF_THE_VILLAGE->Material.EMERALD;};}
    private String pretty(C c){String s=c.name().toLowerCase(Locale.ROOT).replace('_',' ');StringBuilder b=new StringBuilder();for(String x:s.split(" "))b.append(Character.toUpperCase(x.charAt(0))).append(x.substring(1)).append(' ');return b.toString().trim();}
    private void load(){for(String k:Objects.requireNonNullElse(getConfig().getConfigurationSection("classes"),getConfig().createSection("classes")).getKeys(false)){try{cls.put(UUID.fromString(k),C.valueOf(getConfig().getString("classes."+k)));}catch(Exception ignored){}}for(String k:Objects.requireNonNullElse(getConfig().getConfigurationSection("bloodthirsty-until"),getConfig().createSection("bloodthirsty-until")).getKeys(false)){try{bloodUntil.put(UUID.fromString(k),getConfig().getLong("bloodthirsty-until."+k));}catch(Exception ignored){}}}
    private void save(){for(var e:cls.entrySet())getConfig().set("classes."+e.getKey(),e.getValue().name());for(var e:bloodUntil.entrySet())getConfig().set("bloodthirsty-until."+e.getKey(),e.getValue());saveConfig();}
}

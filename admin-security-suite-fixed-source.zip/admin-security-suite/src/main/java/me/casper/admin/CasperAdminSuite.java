package me.casper.admin;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.scheduler.BukkitTask;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class CasperAdminSuite extends JavaPlugin implements Listener, PluginMessageListener {
    public static final String CHANNEL = "casper:suite";
    private final Map<UUID, Long> combatUntil = new ConcurrentHashMap<>();
    private final Set<UUID> verified = ConcurrentHashMap.newKeySet();
    private final Set<UUID> warned = ConcurrentHashMap.newKeySet();
    private final Map<UUID, BukkitTask> pearlTasks = new ConcurrentHashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getMessenger().registerIncomingPluginChannel(this, CHANNEL, this);
        getServer().getMessenger().registerOutgoingPluginChannel(this, CHANNEL);
        Objects.requireNonNull(getCommand("suite")).setExecutor(this::command);
        Bukkit.getScheduler().runTaskTimer(this, this::tickCombatTags, 10L, 10L);
    }

    @Override public void onDisable() {
        getServer().getMessenger().unregisterIncomingPluginChannel(this);
        getServer().getMessenger().unregisterOutgoingPluginChannel(this);
    }

    private boolean command(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Use this command in game."); return true; }
        if (!p.hasPermission("casper.suite.admin")) return true;
        if (a.length > 0 && a[0].equalsIgnoreCase("antiesp")) {
            p.sendMessage(ChatColor.YELLOW + "Anti-ESP: enable Paper anti-xray for the Overworld and cover Y -64..0. This plugin intentionally does not fake packet filtering.");
            p.sendMessage(ChatColor.GRAY + "Paper config: world-settings.default.anticheat.anti-xray.enabled: true (exact path can vary by Paper build). Test after changing it.");
            return true;
        }
        openAdmin(p); return true;
    }

    private void openAdmin(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, "Casper Admin Suite");
        inv.setItem(10, toggle(Material.GRASS_BLOCK, "Overworld", "dimensions.overworld"));
        inv.setItem(12, toggle(Material.NETHERRACK, "Nether", "dimensions.nether"));
        inv.setItem(14, toggle(Material.END_STONE, "End", "dimensions.end"));
        inv.setItem(16, toggle(Material.SPYGLASS, "Companion verification", "verification.enabled"));
        inv.setItem(20, toggle(Material.ELYTRA, "Block Elytra in combat", "combat.block-elytra"));
        ItemStack info = new ItemStack(Material.ENDER_PEARL); ItemMeta im=info.getItemMeta();
        im.setDisplayName(ChatColor.AQUA+"Pearls: "+getConfig().getInt("pearls.despawn-seconds",30)+"s"); info.setItemMeta(im); inv.setItem(22, info);
        p.openInventory(inv);
    }
    private ItemStack toggle(Material m, String name, String path) {
        ItemStack i=new ItemStack(m); ItemMeta meta=i.getItemMeta(); boolean on=getConfig().getBoolean(path,true);
        meta.setDisplayName((on?ChatColor.GREEN:ChatColor.RED)+name+": "+(on?"ON":"OFF")); i.setItemMeta(meta); return i;
    }

    @EventHandler public void adminClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("Casper Admin Suite")) return;
        e.setCancelled(true); if (!(e.getWhoClicked() instanceof Player p) || !p.hasPermission("casper.suite.admin")) return;
        String path=switch(e.getRawSlot()){case 10->"dimensions.overworld";case 12->"dimensions.nether";case 14->"dimensions.end";case 16->"verification.enabled";case 20->"combat.block-elytra";default->null;};
        if(path!=null){getConfig().set(path,!getConfig().getBoolean(path,true));saveConfig();openAdmin(p);}    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void combat(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = attacker(e.getDamager()); if(attacker==null || attacker.equals(victim)) return;
        tag(victim); tag(attacker);
    }
    private Player attacker(Entity d){ if(d instanceof Player p)return p; if(d instanceof Projectile pr && pr.getShooter() instanceof Player p)return p; return null; }
    private void tag(Player p){long end=System.currentTimeMillis()+getConfig().getLong("combat.tag-seconds",15)*1000L;combatUntil.put(p.getUniqueId(),end);p.addScoreboardTag("casper_combat_tagged");if(getConfig().getBoolean("combat.block-elytra",true)&&p.isGliding())p.setGliding(false);}
    private void tickCombatTags(){long now=System.currentTimeMillis();for(Player p:Bukkit.getOnlinePlayers()){Long t=combatUntil.get(p.getUniqueId());if(t!=null&&t<=now){combatUntil.remove(p.getUniqueId());p.removeScoreboardTag("casper_combat_tagged");}}}
    @EventHandler public void quit(PlayerQuitEvent e){UUID id=e.getPlayer().getUniqueId();Long t=combatUntil.remove(id);e.getPlayer().removeScoreboardTag("casper_combat_tagged");if(t!=null&&t>System.currentTimeMillis()&&getConfig().getBoolean("combat.logout-kills",true))e.getPlayer().setHealth(0.0);verified.remove(id);warned.remove(id);}

    @EventHandler public void pearl(ProjectileLaunchEvent e){if(!(e.getEntity() instanceof EnderPearl pearl))return;long ticks=getConfig().getLong("pearls.despawn-seconds",30)*20L;Bukkit.getScheduler().runTaskLater(this,()->{if(!pearl.isDead()&&pearl.isValid())pearl.remove();},ticks);}

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void glide(EntityToggleGlideEvent e){if(!(e.getEntity() instanceof Player p)||!e.isGliding())return;if(getConfig().getBoolean("combat.block-elytra",true)&&isCombatTagged(p)){e.setCancelled(true);p.sendMessage(ChatColor.RED+"You cannot use an Elytra while combat-tagged.");}}
    private boolean isCombatTagged(Player p){Long until=combatUntil.get(p.getUniqueId());return until!=null&&until>System.currentTimeMillis();}

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void portal(PlayerPortalEvent e){World.Environment env=e.getTo()==null?null:e.getTo().getWorld().getEnvironment();if(env==null)return;String path=switch(env){case NORMAL->"dimensions.overworld";case NETHER->"dimensions.nether";case THE_END->"dimensions.end";default->null;};if(path!=null&&!getConfig().getBoolean(path,true)&&!e.getPlayer().hasPermission("casper.suite.admin")){e.setCancelled(true);e.getPlayer().sendMessage(ChatColor.RED+"That dimension is currently disabled.");}}

    @EventHandler public void join(PlayerJoinEvent e){if(!getConfig().getBoolean("verification.enabled",true))return;Player p=e.getPlayer(); if(isFloodgatePlayer(p))return;verified.remove(p.getUniqueId());warned.remove(p.getUniqueId());long warn=getConfig().getLong("verification.first-warning-seconds",8)*20L;long ban=getConfig().getLong("verification.ban-after-seconds",20)*20L;Bukkit.getScheduler().runTaskLater(this,()->{if(p.isOnline()&&!verified.contains(p.getUniqueId())){warned.add(p.getUniqueId());p.sendMessage(ChatColor.RED+"Companion mod verification missing. Install/enable the required companion mod.");sendChallenge(p);}},warn);Bukkit.getScheduler().runTaskLater(this,()->{if(p.isOnline()&&!verified.contains(p.getUniqueId())){String msg=getConfig().getString("verification.ban-message","Required companion mod missing.");Bukkit.getBanList(BanList.Type.NAME).addBan(p.getName(),msg,null,"CasperAdminSuite");p.kickPlayer(msg);}},ban);sendChallenge(p);}
    private void sendChallenge(Player p){String nonce=UUID.randomUUID().toString();p.sendPluginMessage(this,CHANNEL,("CHALLENGE|"+nonce).getBytes(StandardCharsets.UTF_8));}
    @Override public void onPluginMessageReceived(String channel, Player player, byte[] message){if(!channel.equals(CHANNEL))return;String s=new String(message,StandardCharsets.UTF_8);if(s.startsWith("HELLO|1.0")){verified.add(player.getUniqueId());player.sendMessage(ChatColor.GREEN+"Companion mod verified.");}}
    private boolean isFloodgatePlayer(Player p){try{Class<?> api=Class.forName("org.geysermc.floodgate.api.FloodgateApi");Object inst=api.getMethod("getInstance").invoke(null);return (boolean)api.getMethod("isFloodgatePlayer",UUID.class).invoke(inst,p.getUniqueId());}catch(Throwable ignored){return false;}}

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void recipe(PlayerRecipeDiscoverEvent e){ if(getConfig().getStringList("recipes.disabled").contains(e.getRecipe().toString())) e.setCancelled(true); }
}

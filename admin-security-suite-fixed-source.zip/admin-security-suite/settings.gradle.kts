rootProject.name = "admin-security-suite"

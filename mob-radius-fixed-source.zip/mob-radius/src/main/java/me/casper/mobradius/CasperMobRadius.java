package me.casper.mobradius;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class CasperMobRadius extends JavaPlugin implements Listener {
    private final Map<UUID,Integer> radii=new HashMap<>();
    @Override public void onEnable(){saveDefaultConfig();getServer().getPluginManager().registerEvents(this,this);Objects.requireNonNull(getCommand("mobradius")).setExecutor(this::cmd);load();}
    @Override public void onDisable(){save();}
    private boolean cmd(CommandSender s, Command c,String l,String[] a){if(!(s instanceof Player p))return true;open(p);return true;}
    private void open(Player p){Inventory inv=Bukkit.createInventory(null,27,"Mob Radius (chunks)");for(int r=0;r<=12;r++){ItemStack i=new ItemStack(r==0?Material.BARRIER:Material.SPAWNER);ItemMeta m=i.getItemMeta();m.setDisplayName((r==get(p)?ChatColor.GREEN:ChatColor.YELLOW)+"Radius: "+r+" chunks");i.setItemMeta(m);inv.setItem(r,i);}p.openInventory(inv);}
    @EventHandler public void click(InventoryClickEvent e){if(!e.getView().getTitle().equals("Mob Radius (chunks)"))return;e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p))return;int r=e.getRawSlot();if(r>=0&&r<=12){radii.put(p.getUniqueId(),r);save();p.sendMessage(ChatColor.GREEN+"Mob spawn radius set to "+r+" chunks.");open(p);}}
    private int get(Player p){return radii.getOrDefault(p.getUniqueId(),getConfig().getInt("default-radius",8));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void spawn(CreatureSpawnEvent e){switch(e.getSpawnReason()){case NATURAL,CHUNK_GEN,REINFORCEMENTS,PATROL,RAID,VILLAGE_DEFENSE -> { } default->{return;}}Location loc=e.getLocation();for(Player p:loc.getWorld().getPlayers()){double max=12*16.0;double d2=p.getLocation().distanceSquared(loc);if(d2>max*max)continue;int r=get(p);double allowed=r*16.0;if(r==0 || d2>allowed*allowed){e.setCancelled(true);return;}}}
    private void load(){if(!getConfig().isConfigurationSection("players"))return;for(String k:Objects.requireNonNull(getConfig().getConfigurationSection("players")).getKeys(false)){try{radii.put(UUID.fromString(k),getConfig().getInt("players."+k));}catch(Exception ignored){}}}
    private void save(){for(var e:radii.entrySet())getConfig().set("players."+e.getKey(),e.getValue());saveConfig();}
}

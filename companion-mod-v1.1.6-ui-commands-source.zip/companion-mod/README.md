# Casper Companion Mod (Fabric 1.21.11)

This is the Java-side companion requested after the plugins. It is intentionally separate from the Paper plugins.

Current responsibilities:
- respond on `casper:suite` so `CasperAdminSuite` can verify that the companion is present;
- provide the client-side home for custom Java GUIs / class visual behavior;
- future hook point for Camo Expert local-particle hiding and faster-use rendering/input for Ranged Expert.

The server remains authoritative. The companion is not treated as proof that every other installed mod is safe.

package me.casper.companion;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public final class CasperCompanion implements ClientModInitializer {
    public static final String VERSION = "1.1.6";
    private static int handshakeTicks = -1;
    private static boolean handshakeSent = false;
    private static int onboardingTicks = -1;
    private static boolean onboardingPending = false;

    @Override
    public void onInitializeClient() {
        System.out.println("[Casper Companion] INITIALIZED v" + VERSION + " on Fabric; registering casper:suite handshake");

        PayloadTypeRegistry.playC2S().register(HelloPayload.ID, HelloPayload.CODEC);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("info").executes(context -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.execute(() -> {
                    client.setScreen(new InfoScreen(0));
                    System.out.println("[Casper Companion] INFO SCREEN OPENED via /info");
                });
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("casperinfo").executes(context -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.execute(() -> {
                    client.setScreen(new InfoScreen(0));
                    System.out.println("[Casper Companion] INFO SCREEN OPENED via /casperinfo");
                });
                return 1;
            }));
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            // Paper may not advertise plugin channels until just after the play connection is ready.
            // Start a short retry window instead of sending once too early.
            handshakeTicks = 0;
            handshakeSent = false;
            // Only open onboarding after this server proves it supports the Casper channel.
            onboardingTicks = -1;
            onboardingPending = false;
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            handshakeTicks = -1;
            handshakeSent = false;
            onboardingTicks = -1;
            onboardingPending = false;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getNetworkHandler() == null) {
                return;
            }

            if (!handshakeSent && handshakeTicks >= 0) {
                handshakeTicks++;
                try {
                    if (ClientPlayNetworking.canSend(HelloPayload.ID)) {
                        ClientPlayNetworking.send(new HelloPayload(("HELLO|" + VERSION).getBytes(StandardCharsets.UTF_8)));
                        handshakeSent = true;
                        onboardingTicks = 20;
                        onboardingPending = true;
                        System.out.println("[Casper Companion] HANDSHAKE SENT: HELLO|" + VERSION + " on casper:suite");
                    } else if (handshakeTicks % 20 == 0) {
                        System.out.println("[Casper Companion] Waiting for server channel casper:suite (" + handshakeTicks + " ticks)");
                    }
                } catch (Throwable t) {
                    if (handshakeTicks % 20 == 0) {
                        System.err.println("[Casper Companion] Verification send attempt failed: " + t);
                    }
                }

                // Stop retrying after 15 seconds. The server's kick timer is normally 20 seconds.
                if (handshakeTicks >= 300 && !handshakeSent) {
                    System.err.println("[Casper Companion] Server never exposed casper:suite as a sendable channel");
                    handshakeTicks = -1;
                }
            }

            if (onboardingPending) {
                if (onboardingTicks > 0) {
                    onboardingTicks--;
                } else if (client.player != null && client.world != null && client.currentScreen == null) {
                    onboardingPending = false;
                    onboardingTicks = -1;
                    client.setScreen(new InfoScreen(0));
                    System.out.println("[Casper Companion] INFO SCREEN OPENED after verified join");
                }
            }
        });
    }


    public record HelloPayload(byte[] data) implements CustomPayload {
        public static final Id<HelloPayload> ID = new Id<>(Identifier.of("casper", "suite"));
        public static final PacketCodec<RegistryByteBuf, HelloPayload> CODEC = PacketCodec.of(
            (payload, buf) -> buf.writeBytes(payload.data()),
            buf -> {
                byte[] bytes = new byte[buf.readableBytes()];
                buf.readBytes(bytes);
                return new HelloPayload(bytes);
            }
        );

        @Override
        public Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static final class InfoScreen extends Screen {
        private static final int WHITE = 0xFFFFFFFF;
        private static final int MUTED = 0xFFB8B8B8;
        private static final int ACCENT = 0xFFFFE06B;

        private static final List<Page> PAGES = List.of(
            new Page("Welcome / Quick Start", List.of(
                "Welcome to the custom SMP.",
                "This guide explains every custom system and how to use it.",
                "Use /info at any time to reopen this menu.",
                "Your class is assigned randomly the first time you join.",
                "Server-side settings are authoritative; the companion only provides UI/visual features.",
                "Use the Next/Previous buttons to read every section."
            )),
            new Page("Combat Rules", List.of(
                "Combat tagging lasts 15 seconds after PvP combat.",
                "Logging out while combat-tagged causes your character to die.",
                "Elytra use is blocked while combat-tagged.",
                "If combat begins while you are gliding, gliding is stopped.",
                "Ender Pearl projectiles despawn after 30 seconds.",
                "Hunter-class combat involvement can last 90 seconds."
            )),
            new Page("World / Admin Systems", List.of(
                "Admins can enable or disable the Overworld, Nether, and End.",
                "If a dimension is disabled, normal players cannot enter it.",
                "Admins can disable or modify existing crafting recipes.",
                "Recipe changes are intended to persist through restarts.",
                "Underground anti-Xray protection is intended for Y -64 through Y 0.",
                "The anti-dupe / unique-stack-ID system was removed."
            )),
            new Page("Mob Spawn Radius", List.of(
                "Every player has a personal mob-spawn radius from 0 to 12 chunks.",
                "0 means natural mobs do not spawn around you.",
                "1-12 sets how far around you natural spawning is allowed.",
                "The setting applies to all naturally spawning mobs.",
                "The server stores and enforces your selection."
            )),
            new Page("Classes: Miner / Contractor", List.of(
                "MINER: 10% chance to duplicate an ore block when mined.",
                "Fortune does not increase or modify the class's bonus duplicate.",
                "CONTRACTOR: can post contracts and accept contracts.",
                "Only Contractors may accept contracts.",
                "A Contractor may have at most 3 active contracts.",
                "Contracts do not expire; the poster chooses and deposits the reward in the UI."
            )),
            new Page("Classes: Child / Bloodthirsty", List.of(
                "CHILD: -4 max HP, 0.75x size/hitbox, 1.5x sprint speed.",
                "Child hunger drains 1.5x faster.",
                "BLOODTHIRSTY: has Weakness I until getting a player kill.",
                "A player kill gives Strength I for 10 minutes.",
                "Each additional player kill adds 10 minutes to the timer.",
                "Strength stays at I. Death resets the timer back to Weakness I.",
                "The timer continues while offline and is kept separate from normal potions."
            )),
            new Page("Classes: Builder / Hunter", List.of(
                "BUILDER: 10% chance to refund a placed block.",
                "Builder refund is disabled while combat-tagged.",
                "Storage-value blocks and Shulker Boxes are excluded from refunds.",
                "HUNTER: chase range is 50 blocks with about a 30-degree forward cone.",
                "Hunter gets Speed I while the chase condition is active.",
                "Line of sight is not required.",
                "The class Speed effect is designed not to break normal Speed potions."
            )),
            new Page("Classes: Camo / Ranged", List.of(
                "CAMO EXPERT: you do not see your own potion particles.",
                "RANGED EXPERT: ranged weapon use is 40% faster.",
                "Ranged Expert applies to bows, crossbows, and tridents.",
                "Some visual/timing parts require this companion mod."
            )),
            new Page("Classes: Melee / Village", List.of(
                "MELEE EXPERT: choose 2 positive effects and 2 negative effects.",
                "All potion-effect types are available for selection.",
                "Chosen positive effects last 15% longer.",
                "Chosen negative effects last 20% less time.",
                "MASTER OF THE VILLAGE: 20% villager trade discount.",
                "The discount applies after other discounts; final cost is at least 1 emerald."
            )),
            new Page("Changing Class", List.of(
                "A one-time class-change item lets you choose a different class.",
                "It is crafted shapelessly with:",
                "4 Diamond Blocks + 1 Nether Star + 2 Gold Blocks.",
                "Use the item to open class selection.",
                "The item is consumed when used and the class change is one-time.",
                "Admins can use /class choose or /class set <class> to change their own class for free."
            )),
            new Page("Commands", List.of(
                "CLIENT: /info - open this guide.",
                "CLIENT: /casperinfo - backup command to open this guide.",
                "SERVER: /class - show your current class.",
                "SERVER: /class help - show class commands and valid class IDs.",
                "ADMIN: /class choose - open your own class picker for free.",
                "ADMIN: /class set <class> - set your own class for free.",
                "SERVER: /contracts - Contractor contract board/access.",
                "SERVER: /mobradius - open your 0-12 chunk mob-radius selector.",
                "ADMIN: /suite - open the Casper Admin Suite GUI.",
                "ADMIN: /suite antiesp - show the Paper anti-Xray setup reminder."
            )),
            new Page("Companion / Verification", List.of(
                "The Java companion provides client UI and required client-side features.",
                "The security plugin can verify that the companion is present.",
                "Bedrock players use the server's Geyser/Floodgate-compatible interfaces instead.",
                "The server does not magically read every installed mod.",
                "Verification and server-side behaviour checks are used instead.",
                "If you forget anything, run /info again."
            ))
        );

        private final int pageIndex;

        public InfoScreen(int pageIndex) {
            super(Text.literal("Casper SMP Guide"));
            this.pageIndex = Math.max(0, Math.min(pageIndex, PAGES.size() - 1));
        }

        @Override
        protected void init() {
            int bottom = this.height - 30;
            int buttonWidth = 90;
            int gap = 6;
            int total = buttonWidth * 3 + gap * 2;
            int startX = (this.width - total) / 2;

            if (pageIndex > 0) {
                this.addDrawableChild(ButtonWidget.builder(Text.literal("Previous"), b ->
                    this.client.setScreen(new InfoScreen(pageIndex - 1))
                ).dimensions(startX, bottom, buttonWidth, 20).build());
            }

            this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b ->
                this.client.setScreen(null)
            ).dimensions(startX + buttonWidth + gap, bottom, buttonWidth, 20).build());

            if (pageIndex < PAGES.size() - 1) {
                this.addDrawableChild(ButtonWidget.builder(Text.literal("Next"), b ->
                    this.client.setScreen(new InfoScreen(pageIndex + 1))
                ).dimensions(startX + (buttonWidth + gap) * 2, bottom, buttonWidth, 20).build());
            }
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
            // Minecraft 1.21.11 may already blur the screen this frame. Never request
            // another blur here; use an opaque/translucent panel instead.
            context.fill(0, 0, this.width, this.height, 0xD0101010);

            int panelWidth = Math.min(520, Math.max(220, this.width - 32));
            int panelLeft = (this.width - panelWidth) / 2;
            int panelRight = panelLeft + panelWidth;
            int panelTop = 10;
            int panelBottom = Math.max(panelTop + 140, this.height - 38);
            context.fill(panelLeft, panelTop, panelRight, panelBottom, 0xE8202020);
            context.fill(panelLeft, panelTop, panelRight, panelTop + 1, 0xFF5A5A5A);
            context.fill(panelLeft, panelBottom - 1, panelRight, panelBottom, 0xFF5A5A5A);

            Page page = PAGES.get(pageIndex);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Casper SMP Guide"), this.width / 2, panelTop + 10, ACCENT);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(page.title()), this.width / 2, panelTop + 28, WHITE);
            context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Page " + (pageIndex + 1) + " / " + PAGES.size()), this.width / 2, panelTop + 42, MUTED);

            int textLeft = panelLeft + 14;
            int maxTextWidth = Math.max(80, panelWidth - 28);
            int y = panelTop + 62;
            int lineHeight = 11;
            int maxY = panelBottom - 24;

            for (String paragraph : page.lines()) {
                for (String wrapped : wrap(paragraph, maxTextWidth)) {
                    if (y > maxY) {
                        break;
                    }
                    context.drawTextWithShadow(this.textRenderer, Text.literal(wrapped), textLeft, y, WHITE);
                    y += lineHeight;
                }
                y += 3;
                if (y > maxY) {
                    break;
                }
            }

            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("/info or /casperinfo reopens this guide"),
                this.width / 2, panelBottom - 15, MUTED);

            // Render buttons last so they stay clickable/visible on top of the panel.
            super.render(context, mouseX, mouseY, deltaTicks);
        }

        private List<String> wrap(String text, int maxWidth) {
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            StringBuilder current = new StringBuilder();
            for (String word : text.split(" ")) {
                String candidate = current.length() == 0 ? word : current + " " + word;
                if (this.textRenderer.getWidth(candidate) <= maxWidth) {
                    current.setLength(0);
                    current.append(candidate);
                } else {
                    if (current.length() > 0) {
                        lines.add(current.toString());
                    }
                    current.setLength(0);
                    current.append(word);
                }
            }
            if (current.length() > 0) {
                lines.add(current.toString());
            }
            if (lines.isEmpty()) {
                lines.add("");
            }
            return lines;
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }

    private record Page(String title, List<String> lines) {}
}
